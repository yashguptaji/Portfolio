(function(){
  function splitLetters(el){
    var t=el.getAttribute("data-word")||el.textContent;
    el.textContent="";
    for(var i=0;i<t.length;i++){
      var s=document.createElement("span");
      s.textContent=t[i]===" "?"\u00A0":t[i];
      el.appendChild(s);
    }
  }
  document.querySelectorAll(".ascend,.build,.wave").forEach(splitLetters);
})();
(function(){
  var y=document.getElementById("yr"); if(y) y.textContent=new Date().getFullYear();
  var reduce=window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var nav=document.querySelector(".nav");
  var toggle=document.querySelector(".nav-toggle");
  var links=document.querySelector(".nav .links");
  if(toggle&&links){
    toggle.addEventListener("click",function(){var o=links.classList.toggle("open");toggle.innerHTML=o?"&#10005;":"&#9776;";});
    links.querySelectorAll("a").forEach(function(a){a.addEventListener("click",function(){links.classList.remove("open");toggle.innerHTML="&#9776;";});});
  }
  var prog=document.getElementById("prog");
  function setProg(){var h=document.documentElement.scrollHeight-innerHeight;if(prog)prog.style.width=(h>0?scrollY/h*100:0)+"%";if(nav)nav.classList.toggle("scrolled",scrollY>40);}

  if(!reduce && window.gsap && window.ScrollTrigger){
    gsap.registerPlugin(ScrollTrigger);
    if(typeof Lenis!=="undefined"){
      var lenis=new Lenis({lerp:.09,smoothWheel:true});
      lenis.on("scroll",function(){ScrollTrigger.update();setProg();});
      gsap.ticker.add(function(t){lenis.raf(t*1000);});
      gsap.ticker.lagSmoothing(0);
    }else{
      addEventListener("scroll",function(){ScrollTrigger.update();setProg();},{passive:true});
    }
    setProg();

    /* HERO pin+scrub if present */
    if(document.querySelector("#hero")){
      var htl=gsap.timeline({scrollTrigger:{trigger:"#hero",start:"top top",end:"+=120%",pin:true,scrub:1}});
      htl.to("#heroInner",{scale:1.3,opacity:0,y:-60,ease:"none"},0);
      if(document.querySelector(".bg-word")) htl.to(".bg-word",{xPercent:-18,ease:"none"},0);
      if(document.querySelector(".shard")) htl.to(".shard",{y:function(i){return (i%2?-1:1)*220;},ease:"none"},0);
      gsap.from("#heroInner > *",{y:60,opacity:0,duration:1.1,stagger:.12,ease:"power3.out",delay:.15});
    }

    /* depth parallax (mouse) */
    var depthEls=[].slice.call(document.querySelectorAll("[data-depth]"));
    if(depthEls.length){
      window.addEventListener("pointermove",function(e){
        var cx=(e.clientX/innerWidth-.5);
        depthEls.forEach(function(el){var d=parseFloat(el.dataset.depth)||0;gsap.to(el,{x:cx*d*14,duration:.8,ease:"power2.out",overwrite:"auto"});});
      });
    }

    /* generic reveal */
    gsap.utils.toArray(".rv").forEach(function(el){
      gsap.from(el,{y:48,opacity:0,duration:.9,ease:"power3.out",scrollTrigger:{trigger:el,start:"top 84%"}});
    });
    /* staggered groups */
    gsap.utils.toArray(".rv-group").forEach(function(g){
      gsap.from(g.children,{y:50,opacity:0,duration:.85,stagger:.1,ease:"power3.out",scrollTrigger:{trigger:g,start:"top 80%"}});
    });
    /* line mask reveal */
    gsap.utils.toArray(".line-rev > span").forEach(function(s){
      gsap.from(s,{yPercent:120,duration:1,ease:"power4.out",scrollTrigger:{trigger:s,start:"top 88%"}});
    });
    /* parallax y elements */
    gsap.utils.toArray("[data-par]").forEach(function(el){
      gsap.to(el,{yPercent:parseFloat(el.dataset.par),ease:"none",scrollTrigger:{trigger:el,start:"top bottom",end:"bottom top",scrub:true}});
    });
    /* counters */
    document.querySelectorAll("[data-count]").forEach(function(el){
      var end=+el.dataset.count,suf=el.dataset.suffix||"";
      ScrollTrigger.create({trigger:el,start:"top 88%",once:true,onEnter:function(){
        gsap.fromTo(el,{innerText:0},{innerText:end,duration:1.6,ease:"power2.out",snap:{innerText:1},onUpdate:function(){el.innerText=Math.round(this.targets()[0].innerText)+suf;}});
      }});
    });
    /* horizontal marquee */
    if(document.querySelector("#track")) gsap.to("#track",{xPercent:-30,ease:"none",scrollTrigger:{trigger:"#marquee",start:"top bottom",end:"bottom top",scrub:1}});
    /* timeline progress line draw */
    if(document.querySelector(".tl-line")) gsap.fromTo(".tl-line",{scaleY:0},{scaleY:1,transformOrigin:"top",ease:"none",scrollTrigger:{trigger:".timeline",start:"top 60%",end:"bottom 80%",scrub:true}});
  }else{
    addEventListener("scroll",setProg,{passive:true});setProg();
    document.querySelectorAll("[data-count]").forEach(function(el){el.innerText=el.dataset.count+(el.dataset.suffix||"");});
  }

  /* 3D tilt + glow on cards */
  document.querySelectorAll(".tilt").forEach(function(card){
    card.addEventListener("pointermove",function(e){
      var r=card.getBoundingClientRect();
      var px=(e.clientX-r.left)/r.width,py=(e.clientY-r.top)/r.height;
      card.style.setProperty("--mx",(px*100)+"%");card.style.setProperty("--my",(py*100)+"%");
      if(!reduce) card.style.transform="perspective(800px) rotateY("+((px-.5)*9)+"deg) rotateX("+(-(py-.5)*9)+"deg)";
    });
    card.addEventListener("pointerleave",function(){card.style.transform="";});
  });
})();
