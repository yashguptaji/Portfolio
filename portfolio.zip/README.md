# Yash Gupta — Portfolio

Cinematic, scroll-driven personal portfolio. Pure HTML/CSS/JS, no build step, optimized for GitHub Pages.

## Structure
```
index.html      Home / About
career.html     Career progression timeline
projects.html   Projects
contact.html    Contact
css/style.css   Shared design system (loaded once by every page)
js/main.js      Shared scroll engine (loaded once by every page)
assets/         Put your photos here
```
Shared CSS and JS are factored into single files so nothing is duplicated across pages. Each page keeps only its own page-specific styles inline.

## Theme & type
Matte-black palette with off-white accents. Dual display fonts where the type echoes meaning: solid **Bowlby One SC** for stable words, distorted **Rubik Glitch** for "complexity". Career "Progression" ascends like steps, Projects "Built" assembles into place, Contact "Conversation" undulates. Body text is Archivo. All free via Google Fonts.

## Motion
GSAP + ScrollTrigger (pinned hero, scrub, reveals, counters, timeline draw) and Lenis (smooth inertia scroll), all via CDN. Reduced-motion fallback included.

## Customise
- Text: edit the HTML directly.
- Photos: drop two images in `assets/` and point the `.ph` divs in `index.html` at them (e.g. `<img src="assets/me.jpg">`).
- Theme colours: variables at the top of `css/style.css` (`:root`).
- Contact form: front-end only. Point it at Formspree or a mailto to go live.

## Deploy to GitHub Pages
Your handle suggests `yashguptaji.github.io`:
1. Push these files to the root of that repo.
2. Settings → Pages → Source: `main` / `(root)` → Save.
3. Live at https://yashguptaji.github.io in ~1 min.
`.nojekyll` is included so every file (including `css/` and `js/`) serves as-is.
