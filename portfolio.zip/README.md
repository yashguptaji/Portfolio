# Yash Gupta — Portfolio

Cinematic, scroll-driven personal portfolio. Self-contained HTML, no build step, no external CSS/JS files. Deploys to GitHub Pages with zero configuration.

## Files
```
index.html      Home / About
career.html     Career progression timeline
projects.html   Projects
contact.html    Contact
assets/         Put your photos here
```
Each page is fully self-contained (CSS and JS are inlined), so there are no folders to misplace when deploying.

## Theme & type
Matte-black palette with off-white accents. Dual display fonts where the type echoes meaning: solid Bowlby One SC for stable words, distorted Rubik Glitch for "complexity". Career "Progression" ascends like steps, Projects "Built" assembles into place, Contact "Conversation" undulates. Body text is Archivo (all via Google Fonts CDN).

## Motion
GSAP + ScrollTrigger and Lenis smooth scroll, loaded from CDN. Reduced-motion fallback included.

## Customise
- Text: edit the HTML directly.
- Photos: drop two images in `assets/` and point the `.ph` divs in `index.html` at them (e.g. `<img src="assets/me.jpg">`).
- Theme colours: edit the variables in the `:root` block near the top of each page's `<style>`.
- Contact form: front-end only. Point it at Formspree or a mailto to go live.

## Deploy to GitHub Pages
1. Put these four HTML files (plus `.nojekyll` and the `assets` folder) at the ROOT of your `yashguptaji.github.io` repo — not inside a subfolder.
2. Settings → Pages → Source: `main` / `(root)` → Save.
3. Live at https://yashguptaji.github.io in ~1 min.

Because all styles and scripts are inlined, there is nothing else to upload and no paths that can break.
